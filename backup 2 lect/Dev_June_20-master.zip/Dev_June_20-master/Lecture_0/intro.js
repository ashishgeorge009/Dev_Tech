console.log("Hello All :)");
// variable declare
let varName;
// dynamically typed language
varName = 10;
varName = "I am string";
console.log(varName);
// syntax => Java,for while,if, cases
let number = 21;
for (let i = 2; i * i <= number; i++) {
    if (number % i == 0) {
        console.log("Number is not prime");
        return;
    }
}
console.log("Number is prime");
// To check version of node=>node --version
// to run the file => node filename