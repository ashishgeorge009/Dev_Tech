// import nodeJS
let fs = require("fs");
let content = fs.readFileSync("f1.txt","utf-8");
console.log(content);