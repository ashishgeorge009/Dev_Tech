## JavaScript Section
### File System(Node)
* Freecodecamp: Basic JS,Functional Programming,OOPS
* FileSystem Module: https://nodejs.dev/learn/the-nodejs-fs-module
* Require :https://medium.com/edge-coders/requiring-modules-in-node-js-everything-you-need-to-know-e7fbd119be8
#### MDN Link/JS Links
* https://developer.mozilla.org/en-US/docs/Web/JavaScript/A_re-introduction_to_JavaScript
### WebScrapping
* Cheerio: http://zetcode.com/javascript/cheerio/
* https://www.npmjs.com/package/cheerio
