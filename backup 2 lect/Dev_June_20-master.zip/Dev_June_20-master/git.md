# Upload code to github 
## First Time setup
- [ ] git config --global user.email johndoe@example.com
- [ ] git config --global user.name "John Doe"
## (You need to do it always) Hamesha karna hoga 
- [ ] git init
- [ ] touch .gitignore=> add node_modules to it
- [ ] git add .
- [ ] git commit -m "commit message"
- [ ] create a repo on github
- [ ] git remote add origin **Your Repo Name**
- [ ] git push -u origin master