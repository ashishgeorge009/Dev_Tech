// let fs = require("fs");
// // npm install cheerio
// // cheerio module require
// let cheerio = require("cheerio");
// let html = fs.readFileSync("../facts/index.html", "utf-8");   
// // console.log(html);
// let $ = cheerio.load(html);
// // to select  element from the page
// let p = $("p");
// // to get text
// // let pKaData = p.text();
// // console.log(pKaData);
// //  returns array of all the elements
// // let a = $("a");
// // print the content of all anchors
// // console.log(a.text());
// // select element that is inside another element
// // let ulKaP = $("ul p");
// // console.log(ulKaP.text());

// // select a class
// // let classElem=$(".first-para");
// // console.log(classElem.text());

// // select all the element with para class
// // let allelem = $(".para");
// // console.log(allelem.text());
// // select a element with both classes in it
// // let combinedElem = $(".para.first-para");
// // console.log(combinedElem.text());
// // select elements on the basis of id
// let myName=$("#unique");
// console.log(myName.text());


console.log(__filename);