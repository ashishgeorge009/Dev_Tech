let libFn = require("./lib");
const lib = require("./lib");
libFn.fn1("steve");
lib.fn2();
console.log(lib.val)