### 15-06-2020 
* Input:https://www.espncricinfo.com/series/8039/scorecard/656401/australia-vs-england-2nd-match-pool-a-icc-cricket-world-cup-2014-15
* Scarp data of all the batsman that played in the above match 
    * Name ,Runs
### 18-06-2020
* create leaderboard of only from batsmens  of  winning team
* Input: https://www.espncricinfo.com/series/_/id/8039/season/2015/icc-cricket-world-cup 